// ไฟล์: config/database.js
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// แก้ path ให้ชี้ไปที่ไฟล์ Database ของคุณ (สมมติว่าชื่อ database.sqlite)
const dbPath = path.join(__dirname, '../Database/project.sqlite'); 

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('❌ Error connecting to database:', err.message);
    } else {
        console.log('✅ Connected to the SQLite database.');
    }
});

module.exports = db;