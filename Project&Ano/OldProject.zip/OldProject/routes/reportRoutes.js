// ไฟล์: routes/reportRoutes.js
const express = require('express');
const router = express.Router(); // <--- ใช้ Router แทน app
const db = require('../config/database'); // <--- ดึง db จากข้อ 1 มาใช้

// 📊 รายงานที่ 1: รายงานสถานะงานซ่อม (เพิ่มตัวกรอง Status)
router.get('/report_repairs', (req, res) => {
    if (!req.session.user) return res.redirect('/login');

    const tech_id = req.query.tech_id || '';
    const status = req.query.status || '';

    // 1. SQL สำหรับแสดงตารางงานซ่อม
    let sqlList = `
        SELECT r.repair_id, r.receive_date, r.status,
               c.first_name, c.last_name, d.brand, d.model,
               c.first_name || ' ' || c.last_name AS customer_name,
               d.brand || ' ' || d.model AS device_name
        FROM Repairs r
        LEFT JOIN Devices d ON r.device_id = d.device_id
        LEFT JOIN Customers c ON d.customer_id = c.customer_id
        LEFT JOIN Technicians t ON r.technician_id = t.technician_id
        WHERE 1=1 
    `;
    let params = [];
    if (tech_id) { sqlList += ` AND r.technician_id = ?`; params.push(tech_id); }
    if (status) { sqlList += ` AND r.status = ?`; params.push(status); }
    sqlList += ` ORDER BY r.repair_id DESC`;

    // 2. SQL สำหรับ นับจำนวนสถานะงาน (ส่งให้กราฟแท่ง)
    const sqlStatusCount = `SELECT status, COUNT(*) as count FROM Repairs GROUP BY status`;
    
    // 3. SQL สำหรับ นับสัดส่วนยี่ห้อ (ส่งให้กราฟโดนัท)
    const sqlBrandCount = `
        SELECT d.brand, COUNT(r.repair_id) as count 
        FROM Repairs r 
        LEFT JOIN Devices d ON r.device_id = d.device_id 
        GROUP BY d.brand 
        ORDER BY count DESC
    `;

    // 4. ดึงข้อมูลทั้งหมดรวดเดียว (ใช้ callback ซ้อนกันนิดหน่อยครับ)
    db.all("SELECT * FROM Technicians", [], (err, technicians) => {
        db.all(sqlStatusCount, [], (err, statusData) => {
            db.all(sqlBrandCount, [], (err, brandData) => {
                db.all(sqlList, params, (err, repairList) => {
                    
                    res.render('report_repairs', {
                        title: 'รายงานวิเคราะห์งานซ่อม',
                        customerName: req.session.user.username,
                        repairList: repairList,      // โชว์ในตาราง
                        technicians: technicians,    // โชว์ใน Dropdown
                        currentTech: tech_id,
                        currentStatus: status,
                        statusData: statusData,      // ✅ ข้อมูลจริง ส่งให้กราฟแท่ง
                        brandData: brandData         // ✅ ข้อมูลจริง ส่งให้กราฟโดนัท
                    });
                    
                });
            });
        });
    });
});

// 📈 รายงานที่ 2: รายงานสรุปยอดรายได้
router.get('/report_revenue', (req, res) => {
    // 1. เช็คว่าล็อกอินหรือยัง
    if (!req.session.user) return res.redirect('/login');

    // 2. รับค่าตัวกรองจากหน้าเว็บ (ถ้าไม่มีค่า ให้ถือว่าดู "รายวัน" ของ "วันนี้")
    const filterType = req.query.filterType || 'daily'; // 'daily' หรือ 'monthly'
    const filterDate = req.query.filterDate || new Date().toISOString().split('T')[0]; // ค่าเริ่มต้นคือวันนี้ (YYYY-MM-DD)
    const filterMonth = req.query.filterMonth || new Date().toISOString().slice(0, 7); // ค่าเริ่มต้นคือเดือนนี้ (YYYY-MM)

    let sql = ``;
    let params = [];
    let displayTitle = '';

    // 💡 หมายเหตุ: แก้ไขชื่อคอลัมน์ payment_date, amount, status ให้ตรงกับตาราง Payments ของคุณนะครับ
    if (filterType === 'daily') {
        // ค้นหาแบบรายวัน
        sql = `SELECT * FROM Payments WHERE DATE(payment_date) = ?`; 
        params = [filterDate];
        displayTitle = `ประจำวันที่ ${filterDate}`;
    } else {
        // ค้นหาแบบรายเดือน (ใช้ strftime ของ SQLite เพื่อดึงเฉพาะ ปี-เดือน)
        sql = `SELECT * FROM Payments WHERE strftime('%Y-%m', payment_date) = ?`;
        params = [filterMonth];
        displayTitle = `ประจำเดือน ${filterMonth}`;
    }

    // 3. ดึงข้อมูลจากฐานข้อมูล
    db.all(sql, params, (err, payments) => {
        if (err) {
            console.error("Error fetching revenue:", err.message);
            return res.status(500).send("เกิดข้อผิดพลาดในการดึงข้อมูล");
        }

        // 4. นำข้อมูลมาบวกเลขรวมยอดรายได้ทั้งหมดในวัน/เดือนนั้น (อิงจากคอลัมน์ total_cost)
        const totalRevenue = payments.reduce((sum, p) => sum + (p.total_cost || 0), 0);

        // 5. ส่งข้อมูลไปที่หน้าเว็บ
        res.render('report_revenue', {
            title: 'รายงานรายได้',
            customerName: req.session.user.username,
            payments: payments, // รายการชำระเงิน
            totalRevenue: totalRevenue, // ยอดรวมที่บวกแล้ว
            filterType: filterType,
            filterDate: filterDate,
            filterMonth: filterMonth,
            displayTitle: displayTitle
        });
    });
});

module.exports = router; // <--- ส่งออกไปให้ไฟล์หลักใช้งาน